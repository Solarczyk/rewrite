<?php
echo '<a href="../index.html">&laquo; Lista zadań</a>';
echo '<h2>Pobieranie plików</h2>';
echo '<a href="media/test.zip">test.zip</a>';
echo '<br/>';
echo '<a href="files/moved.zip">moved.zip</a>';
echo '<h2>Zadanie</h2>';
echo '<ol>';
echo '<li>Utwórz plik reguł htaccess</li>';
echo '<li>Zastosuj regułę: <code>RewriteRule ^staryAdres nowyAdres.php FLAGI*</code> (* wielkość liter oraz ostatnia reguła)</li>';
echo '<li>Przetestuj rozwiązanie</li>';
echo '</ol>';
