/* Classname			- nazwa klasy
 * Version information	- informacje o wersji
 * Date					- data wydania
 * Copyright notice		- notka prawna
 */
public class Demo {

	public static void main( String[] args)
	{

	}

}
